/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alumni.management;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class PdfGenerator {
    
    private static final Font BigFont = new Font(Font.FontFamily.TIMES_ROMAN,26,
            Font.BOLD,BaseColor.LIGHT_GRAY);
    private static final Font BlueFont = new Font(Font.FontFamily.COURIER, 21,
            Font.BOLDITALIC, BaseColor.BLUE);
    private static final Font SmallBold = new Font(Font.FontFamily.TIMES_ROMAN, 17,
            Font.BOLD);
    private static final Font GrayItalic = new Font(Font.FontFamily.TIMES_ROMAN, 18,
            Font.ITALIC,BaseColor.GRAY);
    private static final Font Green = new Font(Font.FontFamily.HELVETICA, 17,
            Font.BOLDITALIC,BaseColor.GREEN);
    private static final Font Name = new Font(Font.FontFamily.HELVETICA, 27,
            Font.BOLDITALIC,BaseColor.CYAN);

    
    public void pdf(String path,byte[] arr,ArrayList al) throws BadElementException, IOException
    {  
       
        Document doc = new Document();
        try {
              PdfWriter.getInstance(doc, new FileOutputStream(path));
              doc.open();
              Image img = Image.getInstance(arr);
              img.scaleAbsolute(115f, 115f);
              img.setAlignment(Element.ALIGN_RIGHT);
              
              doc.add(img);
              Paragraph paragraph = new Paragraph(al.get(0).toString(),Name); 
              paragraph.setAlignment(Element.ALIGN_CENTER);
              doc.add(paragraph);
              doc.add(new Paragraph("------------------------------------------------------------",BigFont));
              
              
              paragraph = new Paragraph("Address : " + al.get(1).toString(),SmallBold);
              paragraph.setAlignment(Element.ALIGN_LEFT);
              doc.add(paragraph);
              paragraph = new Paragraph("Email ID: " + al.get(2).toString(),SmallBold);
              paragraph.setAlignment(Element.ALIGN_LEFT);
              doc.add(paragraph);
              paragraph = new Paragraph("Phone Number: " + al.get(3).toString(),SmallBold);
              paragraph.setAlignment(Element.ALIGN_LEFT);
              doc.add(paragraph);
              doc.add(new Paragraph("\n"));
              doc.add(new Paragraph("\n"));
              doc.add(new Paragraph("Education ",BlueFont));
              paragraph = new Paragraph("B.E. " + al.get(4) + "(" + al.get(5) + "-" + al.get(6) + ") ",SmallBold);
              paragraph.setAlignment(Element.ALIGN_CENTER);
              doc.add(paragraph);
              paragraph = new Paragraph("Sinhgad Academy of Engineering ",GrayItalic);
              paragraph.setAlignment(Element.ALIGN_CENTER);
              doc.add(paragraph);
              paragraph = new Paragraph("CGPA:-  " + al.get(7) + "/10",Green);
              paragraph.setAlignment(Element.ALIGN_CENTER);
              doc.add(paragraph);
           
              JOptionPane.showMessageDialog(null, "PDF Generated Successfully", "ALERT MESSAGE", JOptionPane.WARNING_MESSAGE);
              doc.close();
        } catch (FileNotFoundException | DocumentException ex) {
            Logger.getLogger(AdminFrame.class.getName()).log(Level.SEVERE, null, ex);
        } 
    
    
  
    }
    
}
